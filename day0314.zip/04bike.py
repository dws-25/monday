
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib import rc

# 음수표기 관리
import matplotlib as mpl
mpl.rc('axes', unicode_minus=False)
mpl.rcParams['axes.unicode_minus']=False

font_name = font_manager.FontProperties(fname='c:/windows/Fonts/malgun.ttf').get_name()
rc('font', family=font_name)

import pandas as pd
import numpy as np
import seaborn as sns 
import time

# 사이킷럿(scikit-learn) 라이브러리 임포트 
#--------------------------------------------------------------------------------------------
train = pd.read_csv('./bike/train.csv' ,  parse_dates=['datetime'] )
test = pd.read_csv('./bike/test.csv'  ,   parse_dates=['datetime'] )

print( train )  # [10,886행rows x 12columns]  #ROC성능 테스트 최적 
print()
print( test )   # [6,493 rows x 9 columns]    #ROC성능 테스트 최적 
print()


arr = np.array([1, 2, 4, 10, 100, 1000])  
log_arr = np.log(arr) 
# 1,     2,         4,            10숫자       100숫자       1000숫자
# [0.    0.69314718  1.38629436   2.30258509   4.60517019   6.90775528 ]
print("log(arr) =", log_arr)            
print()
print()


#첨도 skew() 음수분포가 오른쪽으로, 양수분포가 왼쪽으로 치우침
#왜도 kurt() 0이면 정규분포, 0보다크면 정규분포보다 뾰족한분포
# plt.figure(figsize=(12,7))
fig, ax = plt.subplots(1,1, figsize = (12, 6))  
sns.distplot(train['count'], color='hotpink',  label=train['count'].skew(),ax=ax)
plt.title(" train['count'].skew()")
plt.legend()
plt.show()
print('전 왜도 kurt() 측정' , train['count'].kurt()) # 1.3000929518398334
print('전 첨도 skew() 측정' , train['count'].skew()) # 1.2420662117180776
print()

# plt.figure(figsize=(12,7))
fig, ax = plt.subplots(1,1, figsize = (12, 6))  
train['count_log'] = train['count'].map(lambda i:np.log(i) if i > 0 else 0)
sns.distplot(train['count_log'], color='green',  label=train['count_log'].skew(),ax=ax)
plt.title("후후 train['count_log'].skew() ")
plt.legend()
plt.show()

print('후 왜도 kurt() 측정' , train['count_log'].kurt()) # 0.24662183416964112
print('후 첨도 skew() 측정' , train['count_log'].skew()) # -0.9712277227866112
print()



train['year'] = train['datetime'].dt.year
train['month'] = train['datetime'].dt.month
train['day'] = train['datetime'].dt.day
train['date'] = train['datetime'].dt.date
# train['dayofweek'] = train['datetime'].dt.day_name()    
train['dayofweek'] = train['datetime'].dt.day_of_week  
train['hour'] = train['datetime'].dt.hour
train['minute'] = train['datetime'].dt.minute
train['quarter'] = train['datetime'].dt.quarter
print( train )  
print()  #ok 


test['year'] = test['datetime'].dt.year
test['month'] = test['datetime'].dt.month
test['day'] = test['datetime'].dt.day
test['date'] = test['datetime'].dt.date
# test['dayofweek'] = test['datetime'].dt.day_name()    
test['dayofweek'] = test['datetime'].dt.day_of_week  
test['hour'] = test['datetime'].dt.hour
test['minute'] = test['datetime'].dt.minute
test['quarter'] = test['datetime'].dt.quarter
print( test )  
print()  #ok 


print( train )  # [10,886행rows x 20columns] 
print()
print( test )   # [6,493 rows x 17 columns]    
print(' -' * 40)
print()


#순서3 시간이 엄청 오래걸림 시계열=시간차이  데이터로드 행rows얼마만큼 영향을 주는지확인 차트주식처럼 출력
plt.figure(figsize=(16,4))
sns.lineplot(data=train, x='date', y='count')
plt.xticks(rotation=45)
plt.title("train데이터 date lineplot test ")
plt.show()  #ok 






print()
print()